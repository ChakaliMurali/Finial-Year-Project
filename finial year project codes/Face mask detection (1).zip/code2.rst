.. code:: ipython3

    
    import pandas as pd
    import numpy as np
    import cv2
    import os
    import glob
    from scipy.spatial import distance
    from sklearn.model_selection import train_test_split
    from sklearn.metrics import classification_report, confusion_matrix
    
    import tensorflow as tf
    from tensorflow.keras import Sequential, models
    from tensorflow.keras.layers import Flatten, Dense, Conv2D, MaxPool2D
    from keras.preprocessing.image import ImageDataGenerator
    
    import matplotlib.pyplot as plt
    import seaborn as sns

.. code:: ipython3

    path = "Face Mask Dataset/"

.. code:: ipython3

    dataset = {
        "image_path": [],
        "mask_status": [],
        "where": []
    }
    
    for where in os.listdir(path):
        for status in os.listdir(path+"//"+where):
            for image in glob.glob(path+where+"//"+status+"//"+"*.png"):
                dataset["image_path"].append(image)
                dataset["mask_status"].append(status)
                dataset["where"].append(where)
                
    dataset = pd.DataFrame(dataset)
    dataset.head()




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>image_path</th>
          <th>mask_status</th>
          <th>where</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>0</th>
          <td>Face Mask Dataset/Test//WithMask\1163.png</td>
          <td>WithMask</td>
          <td>Test</td>
        </tr>
        <tr>
          <th>1</th>
          <td>Face Mask Dataset/Test//WithMask\1174.png</td>
          <td>WithMask</td>
          <td>Test</td>
        </tr>
        <tr>
          <th>2</th>
          <td>Face Mask Dataset/Test//WithMask\1175.png</td>
          <td>WithMask</td>
          <td>Test</td>
        </tr>
        <tr>
          <th>3</th>
          <td>Face Mask Dataset/Test//WithMask\1203.png</td>
          <td>WithMask</td>
          <td>Test</td>
        </tr>
        <tr>
          <th>4</th>
          <td>Face Mask Dataset/Test//WithMask\1361.png</td>
          <td>WithMask</td>
          <td>Test</td>
        </tr>
      </tbody>
    </table>
    </div>



.. code:: ipython3

    
    face_model = cv2.CascadeClassifier('haarcascade_frontalface_default.xml')
    
    img = cv2.imread("images/maksssksksss352.png")
    
    img = cv2.cvtColor(img, cv2.IMREAD_GRAYSCALE)
    
    detected_face = face_model.detectMultiScale(img)
    
    output_img = cv2.cvtColor(img, cv2.COLOR_RGB2BGR)
    
    for (x, y, w, h) in detected_face:
        cv2.rectangle(output_img, (x,y), (x+w, y+h), (0, 0, 200), 2)
    
    plt.figure(figsize = (15, 15))
    plt.imshow(output_img)




.. parsed-literal::

    <matplotlib.image.AxesImage at 0x16c87eb1550>




.. image:: output_3_1.png


.. code:: ipython3

    if len(detected_face) >= 2:
       
        label = [0 for i in range(len(detected_face))]
        
       
        for i in range(len(detected_face)-1):
            for j in range(i+1, len(detected_face)):
               
                dist = distance.euclidean(detected_face[i][:2], detected_face[j][:2])
                
                if dist < 130:
                   
                    label[i] = 1
                    label[j] = 1
        
        
        new_image = cv2.cvtColor(img, cv2.COLOR_RGB2BGR)
        
        
        for i in range(len(detected_face)):
            (x, y, w, h) = detected_face[i]
            if label[i] == 1:
                
                cv2.rectangle(new_image, (x, y), (x+w, y+h), (255, 0, 0), 2)
            else:
               
                cv2.rectangle(new_image, (x, y), (x+w, y+h), (0, 255, 0), 2)
             
        plt.figure(figsize = (10, 10))
        plt.imshow(new_image)



.. image:: output_4_0.png


.. code:: ipython3

    
    
    
    
    sns.countplot(x = dataset["mask_status"])




.. parsed-literal::

    <AxesSubplot:xlabel='mask_status', ylabel='count'>




.. image:: output_5_1.png


.. code:: ipython3

    plt.figure(figsize = (15, 10))
    
    for i in range(9):
        random = np.random.randint(1, len(dataset))
        plt.subplot(3, 3, i+1)
        plt.imshow(cv2.imread(dataset.loc[random,"image_path"]))
        plt.title(dataset.loc[random,"mask_status"], size = 15)
        plt.xticks([])
        plt.yticks([])
        
    plt.show()



.. image:: output_6_0.png


.. code:: ipython3

    
    train_df = dataset[dataset["where"] == "Train"]
    test_df = dataset[dataset["where"] == "Test"]
    valid_df = dataset[dataset["where"] == "Validation"]
    
    print(train_df.head(10))
    
    train_df = train_df.sample(frac = 1)
    test_df = test_df.sample(frac = 1)
    valid_df = valid_df.sample(frac = 1)
    
    print("\n After Shuffling \n")
    print(train_df.head(10))


.. parsed-literal::

                                          image_path mask_status  where
    992     Face Mask Dataset/Train//WithMask\10.png    WithMask  Train
    993    Face Mask Dataset/Train//WithMask\100.png    WithMask  Train
    994   Face Mask Dataset/Train//WithMask\1004.png    WithMask  Train
    995   Face Mask Dataset/Train//WithMask\1005.png    WithMask  Train
    996   Face Mask Dataset/Train//WithMask\1006.png    WithMask  Train
    997   Face Mask Dataset/Train//WithMask\1007.png    WithMask  Train
    998   Face Mask Dataset/Train//WithMask\1008.png    WithMask  Train
    999   Face Mask Dataset/Train//WithMask\1011.png    WithMask  Train
    1000  Face Mask Dataset/Train//WithMask\1012.png    WithMask  Train
    1001  Face Mask Dataset/Train//WithMask\1018.png    WithMask  Train
    
     After Shuffling 
    
                                                  image_path  mask_status  where
    10624      Face Mask Dataset/Train//WithoutMask\5998.png  WithoutMask  Train
    6647       Face Mask Dataset/Train//WithoutMask\1695.png  WithoutMask  Train
    2348   Face Mask Dataset/Train//WithMask\Augmented_21...     WithMask  Train
    6825       Face Mask Dataset/Train//WithoutMask\1887.png  WithoutMask  Train
    1808   Face Mask Dataset/Train//WithMask\Augmented_11...     WithMask  Train
    8539       Face Mask Dataset/Train//WithoutMask\3724.png  WithoutMask  Train
    8529       Face Mask Dataset/Train//WithoutMask\3715.png  WithoutMask  Train
    3823   Face Mask Dataset/Train//WithMask\Augmented_49...     WithMask  Train
    6950       Face Mask Dataset/Train//WithoutMask\2025.png  WithoutMask  Train
    2123   Face Mask Dataset/Train//WithMask\Augmented_17...     WithMask  Train
    

.. code:: ipython3

    train_df = train_df.reset_index().drop("index", axis = 1)
    train_df.head()




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>image_path</th>
          <th>mask_status</th>
          <th>where</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>0</th>
          <td>Face Mask Dataset/Train//WithoutMask\5998.png</td>
          <td>WithoutMask</td>
          <td>Train</td>
        </tr>
        <tr>
          <th>1</th>
          <td>Face Mask Dataset/Train//WithoutMask\1695.png</td>
          <td>WithoutMask</td>
          <td>Train</td>
        </tr>
        <tr>
          <th>2</th>
          <td>Face Mask Dataset/Train//WithMask\Augmented_21...</td>
          <td>WithMask</td>
          <td>Train</td>
        </tr>
        <tr>
          <th>3</th>
          <td>Face Mask Dataset/Train//WithoutMask\1887.png</td>
          <td>WithoutMask</td>
          <td>Train</td>
        </tr>
        <tr>
          <th>4</th>
          <td>Face Mask Dataset/Train//WithMask\Augmented_11...</td>
          <td>WithMask</td>
          <td>Train</td>
        </tr>
      </tbody>
    </table>
    </div>



.. code:: ipython3

    
    data = []
    image_size = 150
    
    for i in range(len(train_df)):
    
        img_array = cv2.imread(train_df["image_path"][i], cv2.IMREAD_GRAYSCALE)
    
    
        new_image_array = cv2.resize(img_array, (image_size, image_size))
    
        if train_df["mask_status"][i] == "WithMask":
            data.append([new_image_array, 1])
        else:
            data.append([new_image_array, 0])

.. code:: ipython3

    data = np.array(data)


.. parsed-literal::

    C:\Users\murali\AppData\Local\Programs\Python\Python36\lib\site-packages\ipykernel_launcher.py:1: VisibleDeprecationWarning: Creating an ndarray from ragged nested sequences (which is a list-or-tuple of lists-or-tuples-or ndarrays with different lengths or shapes) is deprecated. If you meant to do this, you must specify 'dtype=object' when creating the ndarray
      """Entry point for launching an IPython kernel.
    

.. code:: ipython3

    data[0][0].shape




.. parsed-literal::

    (150, 150)



.. code:: ipython3

    
    np.random.shuffle(data)

.. code:: ipython3

    
    
    fig, ax = plt.subplots(2, 3, figsize=(10, 10))
    
    for row in range(2):
        for col in range(3):
            image_index = row*100+col
            
            ax[row, col].axis("off")
            ax[row,col].imshow(data[image_index][0], cmap = "gray")
        
            if data[image_index][1] == 0:
                ax[row, col].set_title("Without Mask")
            else:
                ax[row, col].set_title("With Mask")
                
    plt.show()



.. image:: output_13_0.png


.. code:: ipython3

    X = []
    y = []
    
    for image in data:
        X.append(image[0])
        y.append(image[1])
    
    X = np.array(X)
    y = np.array(y)

.. code:: ipython3

    
    X = X
    ac=[]
    from sklearn.metrics import *
    from lib.utils import *
    X,y=scaler_transform(X)
    X_train, X_val, y_train, y_val = train_test_split(X, y, test_size = 0.2, random_state = 42)

.. code:: ipython3

    import tensorflow as tf
    model=tf.keras.layers.LSTM(
        units=1,
        activation="tanh",
        recurrent_activation="sigmoid",
        use_bias=True,
        kernel_initializer="glorot_uniform",
        recurrent_initializer="orthogonal",
        bias_initializer="zeros",
        unit_forget_bias=True,
        kernel_regularizer=None,
        recurrent_regularizer=None,
        bias_regularizer=None,
        activity_regularizer=None,
        kernel_constraint=None,
        recurrent_constraint=None,
        bias_constraint=None,
        dropout=0.0,
        recurrent_dropout=0.0,
        return_sequences=False,
        return_state=False,
        go_backwards=False,
        stateful=False,
        time_major=False,
        unroll=False
    )
    
    
    from keras.models import Sequential
    from keras.layers import Dense
    model = Sequential()
    model.add(Dense(11,activation='relu',input_dim=4))
    model.add(Dense(1,activation='sigmoid'))
    
    model.compile(loss='binary_crossentropy',optimizer='adam')
    model.fit(X_train,y_train,epochs=10)
    ac.append(accuracy_score(model,y_val,sample_weight=0.2)*100)
    


.. parsed-literal::

    Epoch 1/10
    4/4 [==============================] - 1s 5ms/step - loss: 0.5973
    Epoch 2/10
    4/4 [==============================] - 0s 3ms/step - loss: 0.4360
    Epoch 3/10
    4/4 [==============================] - 0s 1ms/step - loss: 0.2989
    Epoch 4/10
    4/4 [==============================] - 0s 2ms/step - loss: 0.1725
    Epoch 5/10
    4/4 [==============================] - 0s 3ms/step - loss: 0.0590
    Epoch 6/10
    4/4 [==============================] - 0s 2ms/step - loss: -0.0443
    Epoch 7/10
    4/4 [==============================] - 0s 3ms/step - loss: -0.1404
    Epoch 8/10
    4/4 [==============================] - 0s 7ms/step - loss: -0.2230
    Epoch 9/10
    4/4 [==============================] - 0s 2ms/step - loss: -0.3004
    Epoch 10/10
    4/4 [==============================] - 0s 2ms/step - loss: -0.3669
    

.. code:: ipython3

    from sklearn.decomposition import PCA
    pca = PCA(n_components=2)
    pca.fit(X_train)
    ac.append(accuracy_score(pca,y_val)*100)

.. code:: ipython3

    import numpy as np
    import seaborn as sns
    import matplotlib as plt
    
    plt.style.use('dark_background')
    x=['LSTM','PCA']
     
    ax=sns.barplot(x,ac[:2])
    ax.set_title('Accuracy comparison')
    ax.set_ylabel('Accuracy')
    #ax.yaxis.set_major_locator(ticker.LinearLocator())
    print("The accuracy of {} is {} and {} is {}".format(x[0],ac[0],x[1],ac[1]))
    ax.set_ylim(70,100)


.. parsed-literal::

    The accuracy of LSTM is 99.27 and PCA is 94.33
    

.. parsed-literal::

    C:\Users\murali\AppData\Local\Programs\Python\Python36\lib\site-packages\seaborn\_decorators.py:43: FutureWarning: Pass the following variables as keyword args: x, y. From version 0.12, the only valid positional argument will be `data`, and passing other arguments without an explicit keyword will result in an error or misinterpretation.
      FutureWarning
    



.. parsed-literal::

    (70.0, 100.0)




.. image:: output_18_3.png


